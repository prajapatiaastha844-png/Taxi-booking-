# Taxi Booking Admin Password Reset

## Run locally

```powershell
python manage.py migrate
python manage.py runserver
```

Open `http://127.0.0.1:8000/admin/forgot-password/`.

The development email backend prints the OTP email directly in the terminal running Django. Create an admin user with `python manage.py createsuperuser` to test the full flow.
