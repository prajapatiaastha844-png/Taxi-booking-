"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from accounts import views as account_views

urlpatterns = [
    path(
        'admin/forgot-password/',
        account_views.forgot_password,
        name='admin-forgot-password',
    ),
    path(
        'admin/forgot-password/verify/',
        account_views.verify_otp,
        name='admin-forgot-password-verify',
    ),
    path(
        'admin/reset/new-password/',
        account_views.set_new_password,
        name='admin-password-reset-new',
    ),
    path(
        'admin/reset/complete/',
        auth_views.PasswordResetCompleteView.as_view(
            template_name='registration/password_reset_complete.html',
        ),
        name='admin-password-reset-complete',
    ),
    path(
        'admin/drivers/',
        account_views.module_placeholder,
        {'module_name': 'drivers'},
        name='admin-module-drivers',
    ),
    path(
        'admin/users/',
        account_views.module_placeholder,
        {'module_name': 'users'},
        name='admin-module-users',
    ),
    path(
        'admin/bookings/',
        account_views.module_placeholder,
        {'module_name': 'bookings'},
        name='admin-module-bookings',
    ),
    path('admin/', admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
