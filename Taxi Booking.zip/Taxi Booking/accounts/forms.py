from django import forms
from django.contrib.auth.forms import SetPasswordForm


class OTPRequestForm(forms.Form):
    email = forms.EmailField(label='Admin email')


class OTPVerificationForm(forms.Form):
    otp = forms.CharField(label='6-digit OTP', min_length=6, max_length=6)

    def clean_otp(self):
        otp = self.cleaned_data['otp']
        if not otp.isdigit():
            raise forms.ValidationError('Enter the six-digit code from your email.')
        return otp


class NewPasswordForm(SetPasswordForm):
    pass
