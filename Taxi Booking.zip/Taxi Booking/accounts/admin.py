from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin

from .models import AdminProfile


class AdminProfileInline(admin.StackedInline):
	model = AdminProfile
	extra = 1
	max_num = 1


class UserAdminWithProfile(UserAdmin):
	inlines = (AdminProfileInline,)


admin.site.unregister(get_user_model())
admin.site.register(get_user_model(), UserAdminWithProfile)
