from django.contrib.auth import get_user_model
from django.core import mail
from django.core.mail import get_connection
from django.test import TestCase, override_settings
from django.urls import reverse
import re

from .models import AdminProfile


class AdminPasswordResetTests(TestCase):
	@override_settings(EMAIL_BACKEND='django.core.mail.backends.console.EmailBackend')
	def test_console_email_backend_is_available(self):
		connection = get_connection()

		self.assertEqual(
			f'{connection.__class__.__module__}.{connection.__class__.__name__}',
			'django.core.mail.backends.console.EmailBackend',
		)

	def test_forgot_password_page_renders_email_field(self):
		response = self.client.get(reverse('admin-forgot-password'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Admin email')
		self.assertContains(response, 'Send OTP')

	def test_reset_email_is_sent_for_admin_account(self):
		User = get_user_model()
		User.objects.create_superuser(
			username='dispatcher',
			email='dispatcher@example.com',
			password='OldPassword123!',
		)

		response = self.client.post(
			reverse('admin-forgot-password'),
			{'email': 'dispatcher@example.com'},
		)

		self.assertRedirects(response, reverse('admin-forgot-password-verify'))
		self.assertEqual(len(mail.outbox), 1)
		self.assertIn('OTP', mail.outbox[0].subject)
		self.assertRegex(mail.outbox[0].body, r'\b\d{6}\b')

	def test_admin_dashboard_shows_name_and_profile_photo(self):
		user = get_user_model().objects.create_superuser(
			username='dispatcher',
			email='dispatcher@example.com',
			password='OldPassword123!',
			first_name='Mira',
			last_name='Khan',
		)
		self.client.force_login(user)

		user_response = self.client.get(
			reverse('admin:auth_user_change', args=[user.pk]),
		)
		self.assertContains(user_response, 'type="file"')

		response = self.client.get(reverse('admin:index'))
		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Mira Khan')
		self.assertContains(response, 'admin-identity__initials')

		AdminProfile.objects.create(user=user, photo='admin-profiles/mira.jpg')
		response = self.client.get(reverse('admin:index'))
		self.assertContains(response, '/media/admin-profiles/mira.jpg')

	def test_module_placeholders_require_staff_and_render(self):
		module_pages = (
			('admin-module-drivers', 'Drivers'),
			('admin-module-users', 'Users'),
			('admin-module-bookings', 'Bookings'),
		)

		for url_name, title in module_pages:
			response = self.client.get(reverse(url_name))
			self.assertRedirects(
				response,
				f'{reverse("admin:login")}?next={reverse(url_name)}',
			)

		user = get_user_model().objects.create_superuser(
			username='dispatcher',
			email='dispatcher@example.com',
			password='OldPassword123!',
		)
		self.client.force_login(user)

		for url_name, title in module_pages:
			response = self.client.get(reverse(url_name))
			self.assertEqual(response.status_code, 200)
			self.assertContains(response, title)
			self.assertContains(response, 'Coming soon')

	def test_otp_allows_password_update(self):
		User = get_user_model()
		User.objects.create_superuser(
			username='dispatcher',
			email='dispatcher@example.com',
			password='OldPassword123!',
		)
		self.client.post(
			reverse('admin-forgot-password'),
			{'email': 'dispatcher@example.com'},
		)
		otp = re.search(r'\b(\d{6})\b', mail.outbox[0].body).group(1)

		response = self.client.post(
			reverse('admin-forgot-password-verify'),
			{'otp': otp},
		)
		self.assertRedirects(response, reverse('admin-password-reset-new'))

		response = self.client.post(
			reverse('admin-password-reset-new'),
			{'new_password1': 'NewPassword123!', 'new_password2': 'NewPassword123!'},
		)
		self.assertRedirects(response, reverse('admin-password-reset-complete'))
		self.assertTrue(self.client.login(username='dispatcher', password='NewPassword123!'))
