import random
import string
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.forms import SetPasswordForm
from django.core.mail import send_mail
from django.shortcuts import redirect, render
from django.utils import timezone

from .forms import OTPRequestForm, OTPVerificationForm

# Create your views here.
OTP_SESSION_KEY = 'admin_password_reset'
OTP_EXPIRY_MINUTES = 10
ADMIN_MODULES = {
	'drivers': {
		'title': 'Drivers',
	'description': 'Manage driver profiles, availability, and account details.',
	},
	'users': {
		'title': 'Users',
	'description': 'Review passenger accounts and manage user details.',
	},
	'bookings': {
		'title': 'Bookings',
	'description': 'Review trip requests, assignments, and booking status.',
	},
}


def _admin_for_email(email):
	return get_user_model().objects.filter(
		email__iexact=email,
		is_staff=True,
		is_active=True,
	).first()


def forgot_password(request):
	form = OTPRequestForm(request.POST or None)
	if request.method == 'POST' and form.is_valid():
		email = form.cleaned_data['email']
		otp = ''.join(random.choices(string.digits, k=6))
		request.session[OTP_SESSION_KEY] = {
			'email': email,
			'otp': otp,
			'expires_at': (timezone.now() + timedelta(minutes=OTP_EXPIRY_MINUTES)).isoformat(),
		}
		user = _admin_for_email(email)
		if user:
			send_mail(
				'Taxi Booking admin password reset OTP',
				f'Your Taxi Booking password reset OTP is {otp}. It expires in {OTP_EXPIRY_MINUTES} minutes.',
				settings.DEFAULT_FROM_EMAIL,
				[user.email],
			)
		return redirect('admin-forgot-password-verify')
	return render(request, 'registration/password_reset_form.html', {'form': form})


def verify_otp(request):
	reset_data = request.session.get(OTP_SESSION_KEY)
	if not reset_data:
		return redirect('admin-forgot-password')

	form = OTPVerificationForm(request.POST or None)
	if request.method == 'POST' and form.is_valid():
		if timezone.now() >= timezone.datetime.fromisoformat(reset_data['expires_at']):
			form.add_error('otp', 'This OTP has expired. Request a new one.')
		elif form.cleaned_data['otp'] != reset_data['otp']:
			form.add_error('otp', 'That OTP is incorrect. Check your email and try again.')
		else:
			request.session[OTP_SESSION_KEY]['verified'] = True
			request.session.modified = True
			return redirect('admin-password-reset-new')
	return render(request, 'registration/password_reset_verify.html', {'form': form})


def set_new_password(request):
	reset_data = request.session.get(OTP_SESSION_KEY)
	if not reset_data or not reset_data.get('verified'):
		return redirect('admin-forgot-password')

	user = _admin_for_email(reset_data['email'])
	if not user:
		request.session.pop(OTP_SESSION_KEY, None)
		return redirect('admin-forgot-password')

	form = SetPasswordForm(user, request.POST or None)
	if request.method == 'POST' and form.is_valid():
		form.save()
		request.session.pop(OTP_SESSION_KEY, None)
		return redirect('admin-password-reset-complete')
	return render(request, 'registration/password_reset_confirm.html', {'form': form, 'validlink': True})


@staff_member_required
def module_placeholder(request, module_name):
	module = ADMIN_MODULES[module_name]
	return render(request, 'admin/module_placeholder.html', {'module': module})
